<!DOCTYPE html>
<html lang="ja" itemscope itemtype="http://schema.org/Blog">
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
<meta content="telephone=no" name="format-detection">
<meta content="address=no" name="format-detection">
<meta name="robots" content="<?php robots(); ?>">
<?php $my_options = get_option( 'extend_name' );?>
<meta name="keywords" content="<?php echo $my_options['keywords'];?>">
<?php if ( $post->post_excerpt ):  ?>
<meta name="description" content="<?php echo esc_attr( $post->post_excerpt ); ?>" />
<?php else: ?>
<meta name="description" content="<?php bloginfo('description'); ?>" />
<?php endif; ?>
<?php if(!empty($my_options['favicon'])) :?>
<link href="<?php echo $my_options['favicon'];?>" rel="icon">
<?php else:?>
<link href="<?php echo get_template_directory_uri();?>/favicon_dummy.ico" rel="icon">    
<?php endif;?>
<?php if(!empty($my_options['webclip'])) :?>
<link href="<?php echo $my_options['webclip'];?>" rel="apple-touch-icon">
<?php else:?>
<link href="<?php echo get_template_directory_uri();?>/img/dummy_webclip.png" rel="apple-touch-icon">    
<?php endif;?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style.css">
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri();?>/style.css">

<title>
<?php if(!is_front_page()):?>
<?php wp_title( '|', true, 'right' ); ?><?php bloginfo('name'); ?>
<?php else:?>
<?php bloginfo('name'); ?>
<?php endif;?>
</title>

<!--OGP開始-->
<meta property="og:locale" content="ja_JP">
<meta property="fb:app_id" content="<?php echo $my_options['fb_appid'];?>" />
<meta property="article:publisher" content="<?php echo $my_options['fb_publisher'];?>" />

<?php
if (is_single()){// 投稿記事
     if(have_posts()): while(have_posts()): the_post();
          echo '<meta property="og:description" content="'.mb_substr(get_the_excerpt(), 0, 100).'あああ">';echo "\n";//抜粋から
     endwhile; endif;
     echo '<meta property="og:type" content="article">';
     echo '<meta property="og:title" content="'; the_title(); echo '">';echo "\n";//投稿記事タイトル
     echo '<meta property="og:url" content="'; the_permalink(); echo '">';echo "\n";//投稿記事パーマリンク
} else {//投稿記事以外（ホーム、カテゴリーなど）
     echo '<meta property="og:description" content="'; bloginfo('description'); echo '">';echo "\n";
     echo '<meta property="og:type" content="website">';
     //「一般設定」で入力したブログの説明文
     echo '<meta property="og:title" content="'; bloginfo('name'); echo '">';echo "\n";//「一般設定」で入力したブログのタイトル
     echo '<meta property="og:url" content="'; bloginfo('url'); echo '">';echo "\n";//「一般設定」で入力したブログのURL
}
?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>">

<?php
$str = $post->post_content;
$searchPattern = '/<img.*?src=(["\'])(.+?)\1.*?>/i';//投稿記事に画像があるか調べる
if (is_single() or is_page() or !is_front_page()){//投稿記事か固定ページの場合
if (has_post_thumbnail()){//アイキャッチがある場合
     $image_id = get_post_thumbnail_id();
     $image = wp_get_attachment_image_src( $image_id, 'full');
     echo '<meta property="og:image" content="'.$image[0].'">';echo "\n";
} else if ( preg_match( $searchPattern, $str, $imgurl ) && !is_archive()) {//アイキャッチは無いが画像がある場合
     echo '<meta property="og:image" content="'.$imgurl[2].'">';echo "\n";
} else {//画像が1つも無い場合
     echo '<meta property="og:image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
} else {//投稿記事や固定ページ以外の場合（ホーム、カテゴリーなど）
     echo '<meta property="og:image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
?>
<!--OGP完了-->

<!-- twitter-card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="<?php echo $my_options['tw_site'];?>">
<?php
if (is_single()){// 投稿記事
     if(have_posts()): while(have_posts()): the_post();
          echo '<meta name="twitter:description" content="'.mb_substr(get_the_excerpt(), 0, 100).'">';echo "\n";//抜粋から
     endwhile; endif;
     echo '<meta name="twitter:title" content="'; the_title(); echo '">';echo "\n";//投稿記事タイトル
} else {//投稿記事以外（ホーム、カテゴリーなど）
     echo '<meta name="twitter:description" content="'; bloginfo('description'); echo '">';echo "\n";//「一般設定」で入力したブログの説明文
     echo '<meta name="twitter:title" content="'; bloginfo('name'); echo '">';echo "\n";//「一般設定」で入力したブログのタイトル
}
?>
<meta name="twitter:creator" content="<?php echo $my_options['tw_creator'];?>">

<?php
$str = $post->post_content;
$searchPattern = '/<img.*?src=(["\'])(.+?)\1.*?>/i';//投稿記事に画像があるか調べる
if (is_single() or is_page() or !is_front_page()){//投稿記事か固定ページの場合
if (has_post_thumbnail()){//アイキャッチがある場合
     $image_id = get_post_thumbnail_id();
     $image = wp_get_attachment_image_src( $image_id, 'full');
     echo '<meta name="twitter:image:src" content="'.$image[0].'">';echo "\n";
} else if ( preg_match( $searchPattern, $str, $imgurl ) && !is_archive()) {//アイキャッチは無いが画像がある場合
     echo '<meta name="twitter:image:src" content="'.$imgurl[2].'">';echo "\n";
} else {//画像が1つも無い場合
     echo '<meta name="twitter:image:src" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
} else {//投稿記事や固定ページ以外の場合（ホーム、カテゴリーなど）
     echo '<meta name="twitter:image:src" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
?>

<meta name="twitter:domain" content="<?php echo $my_options['site-domain'];?>">
<!-- twitter-card 終了-->

<!-- g+_ogp -->
<?php
if (is_single()){// 投稿記事
     if(have_posts()): while(have_posts()): the_post();
          echo '<meta itemprop="description" content="'.mb_substr(get_the_excerpt(), 0, 100).'">';echo "\n";//抜粋から
     endwhile; endif;
     echo '<meta itemprop="name" content="'; the_title(); echo '">';echo "\n";//投稿記事タイトル
} else {//投稿記事以外（ホーム、カテゴリーなど）
     echo '<meta itemprop="description" content="'; bloginfo('description'); echo '">';echo "\n";//「一般設定」で入力したブログの説明文
     echo '<meta itemprop="name" content="'; bloginfo('name'); echo '">';echo "\n";//「一般設定」で入力したブログのタイトル
}
?>

<?php
$str = $post->post_content;
$searchPattern = '/<img.*?src=(["\'])(.+?)\1.*?>/i';//投稿記事に画像があるか調べる
if (is_single() or is_page() or !is_front_page()){//投稿記事か固定ページの場合
if (has_post_thumbnail()){//アイキャッチがある場合
     $image_id = get_post_thumbnail_id();
     $image = wp_get_attachment_image_src( $image_id, 'full');
     echo '<meta itemprop="image" content="'.$image[0].'">';echo "\n";
} else if ( preg_match( $searchPattern, $str, $imgurl ) && !is_archive()) {//アイキャッチは無いが画像がある場合
     echo '<meta itemprop="image" content="'.$imgurl[2].'">';echo "\n";
} else {//画像が1つも無い場合
     echo '<meta itemprop="image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
} else {//投稿記事や固定ページ以外の場合（ホーム、カテゴリーなど）
     echo '<meta itemprop="image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
?>
<!-- g+_ogp終了 -->

<link rel="author" href="<?php echo $my_options['gu_author'];?>">
<link rel="publisher" href="<?php echo $my_options['gu_publisher'];?>">

<?php if( is_home() || is_front_page() ) {
    $canonical = home_url();
} elseif ( is_category() ) {
    $canonical = get_category_link( get_query_var('cat') );
} else if(is_tag()){
    $canonical = get_tag_link(get_queried_object()->term_id);
} elseif ( is_search() ) {
    $canonical = get_search_link();
} elseif (is_post_type_archive()) {
    $canonical = get_post_type_archive_link(get_post_type());
} elseif (is_tax()) {
    $canonical = get_term_link(get_queried_object()->term_id);
} elseif ( is_page() || is_single() ) {
    $canonical = get_permalink();
} else{
    $canonical = home_url();
}
?>
<link rel="canonical" href="<?php echo $canonical;?>">
<?php if(is_amp()):?>
<link rel="amphtml" href="<?php echo $canonical.'?amp=1'; ?>">
<?php endif;?>

<?php if('blog' == get_post_type()):?>
<script type="application/ld+json">
{
    "@context": "http://schema.org",
    "@type": "NewsArticle",
    "mainEntityOfPage":{
        "@type":"WebPage",
        "@id":"<?php the_permalink(); ?>"
    },
    "name": "<?php the_title();?>",
    "headline": "<?php the_title();?>",
    "image": [
        {
            "@type": "ImageObject",
            "url": "<?php
            $image_id = get_post_thumbnail_id();
            $image_url = wp_get_attachment_image_src($image_id, 'full');
            echo $image_url[0];
            ?>",
            "width": <?php echo $image_url[1];?>,
            "height": <?php echo $image_url[2];?>
        }
    ],
    "articleSection": "<?php echo $terms[0]->name;?>",
    "datePublished": "<?php echo get_the_time('c'); ?>",
    "dateModified": "<?php echo get_the_modified_time('c'); ?>",
    "author": {
        "@type": "Person",
        "name": "<?php $post = get_post($post_id); $author = get_userdata($post->post_author); $person_name = get_the_author_meta('user_nicename',$author->ID); echo $person_name;?>"
    },
    "publisher": {
        "@type": "Organization",
        "name": "<?php bloginfo('name'); ?>",
        "logo": {
            "@type": "ImageObject",
            "url": "<?php echo get_stylesheet_directory_uri();?>/img/logo.png"
        }
    },
    "description": "<?php echo mb_substr(get_the_excerpt(), 0, 120); ?>…"
}
</script>
<?php endif;?>

<?php if(is_page('inquiry')):?>
<?php
    if ( function_exists( 'wpcf7_enqueue_scripts' ) ) {
        wpcf7_enqueue_scripts();
    }
 
    if ( function_exists( 'wpcf7_enqueue_styles' ) ) {
        wpcf7_enqueue_styles();
    }
?>
<?php endif;?>

<?php wp_head();?>
</head>
<body <?php body_class();?>>
<header>
    <section class="container flex-between">
        <p class="site-logo"><a href="<?php echo home_url();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/img/logo.png" width="315" height="60" alt="Demo Service"></a></p>
        <button class="navBtn" aria-label="ナビゲーション" aria-controls="gnav" aria-expanded="true">
            <span></span>
        </button>
        <p class="h-phone">
            <a href="tel:<?php echo $my_options['company_tel'];?>"><i class="fas fa-fw fa-phone fa-flip-horizontal"></i> <?php echo $my_options['company_tel'];?></a></a>
            <span>受付時間 10時00分〜19時00分 土日祝定休</span>
        </p>
    </section>
    <section class="h-bottom">
        <nav class="gnav" role="navigation">
            <ul>
                <li><a href="<?php echo home_url();?>">トップページ</a></li>
                <li><a href="<?php echo home_url();?>/aboutus">デモサービスについて</a></li>
                <li><a href="<?php echo home_url();?>/service">サービス案内</a></li>
                <li><a href="<?php echo home_url();?>/company">会社概要</a></li>
                <li><a href="<?php echo home_url();?>/blog">ブログ</a></li>
                <li><a href="<?php echo home_url();?>/inquiry">お問い合わせ</a></li>
            </ul>
        </nav>
    </section>
</header>
<section id="main-contents">
<?php if(!is_front_page()):?>
    <!-- //not-frontpage insert -->

    <section class="page-title">
        <div class="container">
            <h1>
            <!-- page-title-->
                <?php if(is_month()) : ?>
                    ブログアーカイブ：<?php echo get_post_time( 'Y年m月' ); ?>
                <?php elseif(is_year()) :?>
                    ブログアーカイブ：<?php echo get_post_time( 'Y年' ); ?>
                <?php elseif(is_post_type_archive()):?>
                    <?php post_type_archive_title();?>
                <?php elseif(is_search()):?>
                    <?php printf( __( 'Search Results for: %s', 'altitude' ), '<span>' . get_search_query() . '</span>' ); ?>
                <?php elseif(is_404()):?>
                    404 Not found.
                <?php else:?>
                    <?php the_title();?>
                <?php endif;?>
            <!-- //page-title -->
            </h1>

            <div class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">
                <ol itemscope="" itemtype="http://schema.org/BreadcrumbList">
                <?php if(function_exists('bcn_display'))
                {
                    bcn_display();
                }?>
                </ol>
            </div>
                
        </div>
    </section>
    <section class="eyecatch">
        <?php if(!has_post_thumbnail()) :?>
            <img src="<?php echo get_stylesheet_directory_uri();?>/img/default_thumb.png"/>
        <?php else:?>
            <?php the_post_thumbnail('full-size');?>
        <?php endif;?>
    </section>

    <!-- //not-frontpage insert -->
<?php endif;?>
<?php if(!is_front_page()):?>
    <!-- //not-frontpage insert -->
    <section class="page-body twocolumn reverse">
    <!-- //not-frontpage insert -->
<?php endif;?>
    <main><!-- body -->