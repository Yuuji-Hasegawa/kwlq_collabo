<!doctype html>
<html amp <?php echo AMP_HTML_Utils::build_attributes_string( $this->get( 'html_tag_attributes' ) ); // WPCS: XSS ok. ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
<?php if( is_home() || is_front_page() ) {
    $canonical = home_url();
} elseif ( is_category() ) {
    $canonical = get_category_link( get_query_var('cat') );
} else if(is_tag()){
    $canonical = get_tag_link(get_queried_object()->term_id);
} elseif ( is_search() ) {
    $canonical = get_search_link();
} elseif (is_post_type_archive()) {
    $canonical = get_post_type_archive_link(get_post_type());
} elseif (is_tax()) {
    $canonical = get_term_link(get_queried_object()->term_id);
} elseif ( is_page() || is_single() ) {
    $canonical = get_permalink();
} else{
    $canonical = home_url();
}
?>
<link rel="canonical" href="<?php echo $canonical;?>">
<?php if(is_amp()):?>
<link rel="amphtml" href="<?php echo $canonical.'?amp=1'; ?>">
<?php endif;?>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<script async custom-element="amp-social-share" src="https://cdn.ampproject.org/v0/amp-social-share-0.1.js"></script>
<script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script type="application/ld+json">
{
    "@context": "http://schema.org",
    "@type": "NewsArticle",
    "mainEntityOfPage":{
        "@type":"WebPage",
        "@id":"<?php the_permalink(); ?>" // パーマリンクを取得
    },
    "headline": "<?php the_title();?>", // ページタイトルを取得
    "image": {
        "@type": "ImageObject",
        "url": "<?php // アイキャッチ画像URLを取得
        $image_id = get_post_thumbnail_id();
        $image_url = wp_get_attachment_image_src($image_id, true);
        echo $image_url[0];
        ?>",
        "width": 840,
        "height": 630
    },
    "datePublished": "<?php the_time('Y/m/d') ?>", // 記事投稿時間
    "dateModified": "<?php the_modified_date('Y/m/d') ?>", // 記事更新時間
    "author": {
        "@type": "Person",
        "name": "<?php the_author_meta('nickname'); ?>" // 投稿者ニックネーム
    },
    "publisher": {
        "@type": "Organization",
        "name": "<?php bloginfo('name'); ?>", // サイト名
        "logo": {
            "@type": "ImageObject",
            "url": "<?php echo get_stylesheet_directory_uri()();?>/img/logo.png", // ロゴ画像
            "width": 1313,
            "height": 250
        }
    },
    "description": "<?php echo mb_substr(strip_tags($post-> post_content), 0, 60); ?>" // 抜粋
}
</script>
<style amp-custom>
    <?php $this->load_parts( array( 'style' ) ); ?>
    <?php do_action( 'amp_post_template_css', $this ); ?>
</style>

<?php $my_options = get_option( 'extend_name' );?>
<meta name="keywords" content="<?php echo $my_options['keywords'];?>">
<?php if ( $post->post_excerpt ):  ?>
<meta name="description" content="<?php echo esc_attr( $post->post_excerpt ); ?>" />
<?php else: ?>
<meta name="description" content="<?php bloginfo('description'); ?>" />
<?php endif; ?>

<!--OGP開始-->
<meta property="og:locale" content="ja_JP">
<meta property="fb:app_id" content="<?php echo $my_options['fb_appid'];?>" />
<meta property="article:publisher" content="<?php echo $my_options['fb_publisher'];?>" />

<?php
if (is_single()){// 投稿記事
     if(have_posts()): while(have_posts()): the_post();
          echo '<meta property="og:description" content="'.mb_substr(get_the_excerpt(), 0, 100).'あああ">';echo "\n";//抜粋から
     endwhile; endif;
     echo '<meta property="og:type" content="article">';
     echo '<meta property="og:title" content="'; the_title(); echo '">';echo "\n";//投稿記事タイトル
     echo '<meta property="og:url" content="'; the_permalink(); echo '">';echo "\n";//投稿記事パーマリンク
} else {//投稿記事以外（ホーム、カテゴリーなど）
     echo '<meta property="og:description" content="'; bloginfo('description'); echo '">';echo "\n";
     echo '<meta property="og:type" content="website">';
     //「一般設定」で入力したブログの説明文
     echo '<meta property="og:title" content="'; bloginfo('name'); echo '">';echo "\n";//「一般設定」で入力したブログのタイトル
     echo '<meta property="og:url" content="'; bloginfo('url'); echo '">';echo "\n";//「一般設定」で入力したブログのURL
}
?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>">

<?php
$str = $post->post_content;
$searchPattern = '/<img.*?src=(["\'])(.+?)\1.*?>/i';//投稿記事に画像があるか調べる
if (is_single() or is_page() or !is_front_page()){//投稿記事か固定ページの場合
if (has_post_thumbnail()){//アイキャッチがある場合
     $image_id = get_post_thumbnail_id();
     $image = wp_get_attachment_image_src( $image_id, 'full');
     echo '<meta property="og:image" content="'.$image[0].'">';echo "\n";
} else if ( preg_match( $searchPattern, $str, $imgurl ) && !is_archive()) {//アイキャッチは無いが画像がある場合
     echo '<meta property="og:image" content="'.$imgurl[2].'">';echo "\n";
} else {//画像が1つも無い場合
     echo '<meta property="og:image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
} else {//投稿記事や固定ページ以外の場合（ホーム、カテゴリーなど）
     echo '<meta property="og:image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
?>
<!--OGP完了-->

<!-- twitter-card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="<?php echo $my_options['tw_site'];?>">
<?php
if (is_single()){// 投稿記事
     if(have_posts()): while(have_posts()): the_post();
          echo '<meta name="twitter:description" content="'.mb_substr(get_the_excerpt(), 0, 100).'">';echo "\n";//抜粋から
     endwhile; endif;
     echo '<meta name="twitter:title" content="'; the_title(); echo '">';echo "\n";//投稿記事タイトル
} else {//投稿記事以外（ホーム、カテゴリーなど）
     echo '<meta name="twitter:description" content="'; bloginfo('description'); echo '">';echo "\n";//「一般設定」で入力したブログの説明文
     echo '<meta name="twitter:title" content="'; bloginfo('name'); echo '">';echo "\n";//「一般設定」で入力したブログのタイトル
}
?>
<meta name="twitter:creator" content="<?php echo $my_options['tw_creator'];?>">

<?php
$str = $post->post_content;
$searchPattern = '/<img.*?src=(["\'])(.+?)\1.*?>/i';//投稿記事に画像があるか調べる
if (is_single() or is_page() or !is_front_page()){//投稿記事か固定ページの場合
if (has_post_thumbnail()){//アイキャッチがある場合
     $image_id = get_post_thumbnail_id();
     $image = wp_get_attachment_image_src( $image_id, 'full');
     echo '<meta name="twitter:image:src" content="'.$image[0].'">';echo "\n";
} else if ( preg_match( $searchPattern, $str, $imgurl ) && !is_archive()) {//アイキャッチは無いが画像がある場合
     echo '<meta name="twitter:image:src" content="'.$imgurl[2].'">';echo "\n";
} else {//画像が1つも無い場合
     echo '<meta name="twitter:image:src" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
} else {//投稿記事や固定ページ以外の場合（ホーム、カテゴリーなど）
     echo '<meta name="twitter:image:src" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
?>

<meta name="twitter:domain" content="<?php echo $my_options['site-domain'];?>">
<!-- twitter-card 終了-->

<!-- g+_ogp -->
<?php
if (is_single()){// 投稿記事
     if(have_posts()): while(have_posts()): the_post();
          echo '<meta itemprop="description" content="'.mb_substr(get_the_excerpt(), 0, 100).'">';echo "\n";//抜粋から
     endwhile; endif;
     echo '<meta itemprop="name" content="'; the_title(); echo '">';echo "\n";//投稿記事タイトル
} else {//投稿記事以外（ホーム、カテゴリーなど）
     echo '<meta itemprop="description" content="'; bloginfo('description'); echo '">';echo "\n";//「一般設定」で入力したブログの説明文
     echo '<meta itemprop="name" content="'; bloginfo('name'); echo '">';echo "\n";//「一般設定」で入力したブログのタイトル
}
?>

<?php
$str = $post->post_content;
$searchPattern = '/<img.*?src=(["\'])(.+?)\1.*?>/i';//投稿記事に画像があるか調べる
if (is_single() or is_page() or !is_front_page()){//投稿記事か固定ページの場合
if (has_post_thumbnail()){//アイキャッチがある場合
     $image_id = get_post_thumbnail_id();
     $image = wp_get_attachment_image_src( $image_id, 'full');
     echo '<meta itemprop="image" content="'.$image[0].'">';echo "\n";
} else if ( preg_match( $searchPattern, $str, $imgurl ) && !is_archive()) {//アイキャッチは無いが画像がある場合
     echo '<meta itemprop="image" content="'.$imgurl[2].'">';echo "\n";
} else {//画像が1つも無い場合
     echo '<meta itemprop="image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
} else {//投稿記事や固定ページ以外の場合（ホーム、カテゴリーなど）
     echo '<meta itemprop="image" content="'; echo $my_options['ogp_img']; echo '">'; echo "\n";
}
?>
<!-- g+_ogp終了 -->

<link rel="author" href="<?php echo $my_options['gu_author'];?>">
<link rel="publisher" href="<?php echo $my_options['gu_publisher'];?>">

<title>
<?php if(!is_front_page()):?>
<?php wp_title( '|', true, 'right' ); ?><?php bloginfo('name'); ?>
<?php else:?>
<?php bloginfo('name'); ?>
<?php endif;?>
</title>

<meta name="amp-google-client-id-api" content="googleanalytics">
<!-- AMP Analytics --><script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
</head>
<body <?php echo esc_attr( $this->get( 'body_class' ) ); ?>>

<header>
    <section class="container flex-between">
        <p class="site-logo"><a href="<?php echo home_url();?>"><amp-img src="<?php echo get_stylesheet_directory_uri();?>/img/logo.png" width="315" height="60" alt="Demo SErvice"></amp-img></a></p>
        <button on="tap:sidebar.toggle" class="navBtn" aria-label="ナビゲーション" aria-controls="gnav" aria-expanded="true">
          <span></span>
        </button>
    </section>
    <amp-sidebar id="sidebar" layout="nodisplay" side="right">
        <button on="tap:sidebar.toggle" class="navBtn" aria-label="ナビゲーション" aria-controls="gnav" aria-expanded="true">
          <span class="is-nav-open"></span>
        </button>
        <nav class="gnav" role="navigation">
            <ul>
                <li><a href="<?php echo home_url();?>">トップページ</a></li>
                <li><a href="<?php echo home_url();?>/aboutus">デモサービスについて</a></li>
                <li><a href="<?php echo home_url();?>/service">サービス案内</a></li>
                <li><a href="<?php echo home_url();?>/company">会社概要</a></li>
                <li><a href="<?php echo home_url();?>/blog">ブログ</a></li>
                <li><a href="<?php echo home_url();?>/inquiry">お問い合わせ</a></li>
            </ul>
        </nav>
    </amp-sidebar>
</header>

<section id="main-contents">
	<section class="page-title">
        <div class="container">
            <h1>
            <!-- page-title-->
                <?php if(is_month()) : ?>
                    ブログアーカイブ：<?php echo get_post_time( 'Y年m月' ); ?>
                <?php elseif(is_year()) :?>
                    ブログアーカイブ：<?php echo get_post_time( 'Y年' ); ?>
                <?php elseif(is_post_type_archive()):?>
                    <?php post_type_archive_title();?>
                <?php elseif(is_search()):?>
                    <?php printf( __( 'Search Results for: %s', 'altitude' ), '<span>' . get_search_query() . '</span>' ); ?>
                <?php elseif(is_404()):?>
                    404 Not found.
                <?php else:?>
                    <?php the_title();?>
                <?php endif;?>
            <!-- //page-title -->
            </h1>

            <div class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">
                <ol itemscope="" itemtype="http://schema.org/BreadcrumbList">
                <?php if(function_exists('bcn_display'))
                {
                    bcn_display();
                }?>
                </ol>
            </div>
                
        </div>
    </section>

    <section class="eyecatch">
        <?php if(!has_post_thumbnail()) :?>
            <amp-img src="<?php echo get_stylesheet_directory_uri();?>/img/default_thumb.png" width="840" height="630" alt="" layout="responsive"></amp-img>
        <?php else:?>
            <?php $image_id = get_post_thumbnail_id (); $image_url = wp_get_attachment_image_src ($image_id, true);?>
            <amp-img src="<?php echo $image_url[0];?>" width="<?php echo $image_url[1];?>" height="<?php echo $image_url[2];?>" layout="responsive"></amp-img>
        <?php endif;?>
    </section>

	<section class="page-body">
        <main>