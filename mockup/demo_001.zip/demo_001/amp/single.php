<?php $this->load_parts( array( 'header' ) ); ?>
	<article class="body-content">
		<div class="container">
			<?php if(have_posts()): while(have_posts()): the_post();?>
				<?php the_content();?>
				<p><?php the_time('Y.m.d');?></p>
			<?php endwhile; endif;?>
		</div>
	</article>

	<section class="cta">
		<div class="cta-body tcenter">
			<h3>お問い合わせ</h3>
			<p>弊社に関するお問い合わせやご相談などございましたら、<br>お電話またはお問い合わせフォームをご利用ください。</p>
			<div class="cta-phone">
				<a href="tel:<?php echo $my_options['company_tel'];?>"><i class="fas fa-fw fa-phone fa-flip-horizontal"></i> <?php echo $my_options['company_tel'];?></a>
				<span>受付時間 10時00分〜19時00分 土日祝定休</span>
			</div>
			<button class="default box-center mt2rem"><a href="<?php echo home_url();?>/inquiry"><i class="far fa-fw fa-envelope"></i>お問い合わせ</a></button>
		</div>
	</section>

	<section class="sns-btn">
		<div class="container">
			<ul class="box-center flex-list list-none  mt2rem mb2rem">
				<li class="tcenter"><amp-social-share type="facebook" data-param-app_id="<?php echo get_option('fb_appid');?>"></amp-social-share></li>
				<li class="tcenter"><amp-social-share type="twitter"></amp-social-share></li>
				<li class="tcenter"><amp-social-share type="gplus"></amp-social-share></li>
			</ul>
		</div>
	</section>
		
</main>
<?php $this->load_parts( array( 'sidebar' ) ); ?>
<?php $this->load_parts( array( 'footer' ) ); ?>