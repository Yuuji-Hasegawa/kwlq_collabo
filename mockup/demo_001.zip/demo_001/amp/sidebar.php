<aside>

	<div class="container">
		<!-- widget area -->
			<?php if ( ! is_active_sidebar( 'widget-sidebar' ) ) {return;}?>
			<?php dynamic_sidebar( 'widget-sidebar' ); ?>
		<!-- //widget area -->
	</div>
	
</aside>