<?php
/*
YARPP Template: Thumbnails
Description: Requires a theme which supports post thumbnails
Author: mitcho (Michael Yoshitaka Erlewine)
*/ ?>
<section class="related-post blogs">
	<div class="container">
		<h2>Related Post</h2>
		<?php if (have_posts()):?>

		<div class="flex-list blog-list">
			<?php while (have_posts()) : the_post(); ?>
				<?php if (has_post_thumbnail()):?>

					<div class="flex-half mb2rem">
						<p class="blog-thumb">
							<a href="<?php the_permalink();?>">
								<?php if(!has_post_thumbnail()) :?>
										<img src="<?php echo get_stylesheet_directory_uri();?>/img/default_thumb.png"/>
								<?php else:?>
									<?php the_post_thumbnail('full-size');?>
								<?php endif;?>
							</a>
						</p>
						<p class="blog-text">
							<span><?php the_time('Y.m.d');?></span>
							<span><a href="<?php the_permalink();?>"><?php the_title();?></a></span>
							<span><?php the_excerpt();?></span>
						</p>
					</div>

				<?php endif; ?>
			<?php endwhile; ?>
		</div>

		<?php else: ?>

			<p>関連記事はありませんでした。</p>
		
		<?php endif; ?>

	</div>
</section>