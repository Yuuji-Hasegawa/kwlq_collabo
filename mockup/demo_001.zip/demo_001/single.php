<?php $my_options = get_option( 'extend_name' );?>
<?php get_header();?>
	<article class="body-content">
		<div class="container">
			<?php if(have_posts()): while(have_posts()): the_post();?>
				<?php the_content();?>
				<p><?php the_time('Y.m.d');?></p>
			<?php endwhile; endif;?>
		</div>
	</article>

	<section class="cta">
		<div class="cta-body tcenter">
			<h3>お問い合わせ</h3>
			<p>弊社に関するお問い合わせやご相談などございましたら、<br>お電話またはお問い合わせフォームをご利用ください。</p>
			<div class="cta-phone">
				<a href="tel:<?php echo $my_options['company_tel'];?>"><i class="fas fa-fw fa-phone fa-flip-horizontal"></i> <?php echo $my_options['company_tel'];?></a>
				<span>受付時間 10時00分〜19時00分 土日祝定休</span>
			</div>
			<button class="default box-center mt2rem"><a href="<?php echo home_url();?>/inquiry"><i class="far fa-fw fa-envelope"></i>お問い合わせ</a></button>
		</div>
	</section>

	<section class="sns-btn">
		<div class="container">
			<?php
				$url_encode=urlencode(get_permalink());
				$title_encode=urlencode(get_the_title());
			?>
			<ul class="box-center flex-list list-none  mt2rem mb2rem">
				<li class="fbbtn tcenter"><a href="http://www.facebook.com/sharer.php?src=bm&u=<?php echo $url_encode;?>&t=<?php echo $title_encode;?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"><i class="fab fa-fw fa-facebook-square"></i></a></li>
				<li class="twbtn tcenter"><a href="http://twitter.com/intent/tweet?url=<?php echo $url_encode ?>&text=<?php echo $title_encode ?>&tw_p=tweetbutton"><i class="fab fa-fw fa-twitter-square"></i></a></li>
				<li class="gobtn tcenter"><a href="https://plus.google.com/share?url=<?php echo $url_encode;?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=500');return false;"><i class="fab fa-fw fa-google-plus-square"></i></a></li>
			</ul>
		</div>
	</section>

	<?php related_posts();?>

</main><!-- // main  -->
<?php get_sidebar();?>

<?php get_footer();?>