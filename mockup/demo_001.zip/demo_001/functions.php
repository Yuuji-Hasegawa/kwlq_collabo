<?php
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
function theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );

}

function shortcode_ctemplateurl() {
    return get_stylesheet_directory_uri();
}
add_shortcode('ctemplate_url', 'shortcode_ctemplateurl');

/* ログイン画面カスタマイズ */
function custom_login() { ?>
<style>
/* ここにスタイルを記述 */
.login {
	background: url(<?php echo get_stylesheet_directory_uri(); ?>/img/landing-bg.jpg) no-repeat center center;
	background-size: cover;
}
</style>
<script>
    /* ここにスクリプトを記述 */
</script>

<?php }

/* 外部ファイル読み込みver*/
/*
function custom_login() {
  $files = '<link rel="stylesheet" href=" ' . get_bloginfo( 'template_directory' ) . ' /css/login.css" />
      <script src="' . get_bloginfo( 'template_directory' ) . ' /js/jquery.js"></script>
      <script src="' . get_bloginfo( 'template_directory' ) . '/js/login.js"></script>';
  echo $files;
}
*/

add_action( 'login_enqueue_scripts', 'custom_login' );

/* ロゴの差し替え */
function custom_login_logo() { ?>
<style>
.login #login h1 a {
	width: 315px;
	height: 60px;
	background: url(<?php echo get_stylesheet_directory_uri(); ?>/img/logo.png) no-repeat 0 0;
}
</style>
<?php }
add_action( 'login_enqueue_scripts', 'custom_login_logo' );

?>