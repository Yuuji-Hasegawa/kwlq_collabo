<?php $my_options = get_option( 'extend_name' );?>
<?php if(!is_front_page()):?>
    </section><!-- //.page-body -->
<?php endif;?>
</section><!-- //#main-contents -->

<?php if(is_front_page()):?>
<section class="cta">
	<div class="cta-body tcenter">
		<h3>お問い合わせ</h3>
		<p>弊社に関するお問い合わせやご相談などございましたら、<br>お電話またはお問い合わせフォームをご利用ください。</p>
		<div class="cta-phone">
			<a href="tel:<?php echo $my_options['company_tel'];?>"><i class="fas fa-fw fa-phone fa-flip-horizontal"></i> <?php echo $my_options['company_tel'];?></a>
			<span>受付時間 00時00分〜00時00分<br>x曜日・祝日定休</span>
		</div>
		<button class="default box-center mt2rem"><a href="<?php echo home_url();?>/inquiry"><i class="far fa-fw fa-envelope"></i>お問い合わせ</a></button>
	</div>
</section>
<?php endif;?>

<footer>
	<div class="container">
		<section class="ft-address box-center">
			<p class="ft-logo tcenter"><a href="<?php echo home_url();?>"><img src="<?php echo get_template_directory_uri();?>/img/logo_s.png" width="280" height="60" alt="logo"></a></p>
			<p><?php echo $my_options['company_name'];?> TEL:<a href="tel:<?php echo $my_options['company_tel'];?>"> <?php echo $my_options['company_tel'];?></a></p>
			<p>〒<?php echo $my_options['company_zip'];?><br><?php echo $my_options['company_address'];?></p>
		</section>
		<nav class="ft-nav">
			<ul class="flex-list box-center">
				<li class="tcenter"><a href="<?php echo home_url();?>/company">会社概要</a></li>
				<li class="tcenter"><a href="<?php echo home_url();?>/site-policy">利用規約</a></li>
				<li class="tcenter"><a href="<?php echo home_url();?>/privacy-policy">個人情報保護方針</a></li>
				<li class="tcenter"><a href="<?php echo home_url();?>/sitemaps">サイトマップ</a></li>					
			</ul>
		</nav>
	</div>
	<section class="ft-bottom flex-between">
		<nav>
			<ul class="flex-list">
				<li><a href="https://twitter.com/"><i class="fab fa-fw fa-twitter"></i></a></li>
				<li><a href="https://www.facebook.com/"><i class="fab fa-fw fa-facebook-f"></i></a></li>
				<li><a href="https://www.instagram.com/"><i class="fab fa-fw fa-instagram"></i></a></li>
			</ul>
		</nav>
		<p class="cpt">© <?php echo $my_options['copyright'];?></p>
	</section>
</footer>
<script src="<?php echo get_template_directory_uri();?>/js/umbrella.min.js"></script>
<?php
  // JSのインライン化
  echo '<script>';
  echo file_get_contents(get_template_directory_uri()."/js/header.min.js")."\n";
  echo '</script>';
?>
<?php wp_footer(); ?>
</body>
</html>