<?php get_header();?>
	<article class="body-content">
		<div class="container">
			<?php if(is_post_type_archive('news')): ?>
				
				<?php if(have_posts()): while(have_posts()): the_post();?>
					<dl class="news-dl">
						<dt><?php the_time('Y.m.d');?></dt>
						<dd><a href="<?php the_permalink();?>"><?php the_title();?></a></dd>
					</dl>
				<?php endwhile; endif;?>

			<?php else: ?>
				<div class="flex-list blog-list">
				<?php if(have_posts()): while(have_posts()): the_post();?>

					<div class="flex-half mb2rem">
						<p class="blog-thumb">
							<a href="<?php the_permalink();?>">
								<?php if(!has_post_thumbnail()) :?>
										<img src="<?php echo get_template_directory_uri();?>/img/thumb_dummy.png"/>
								<?php else:?>
									<?php the_post_thumbnail('full-size');?>
								<?php endif;?>
							</a>
						</p>
						<p class="blog-text">
							<span><?php the_time('Y.m.d');?></span>
							<span><a href="<?php the_permalink();?>"><?php the_title();?></a></span>
							<span><?php the_excerpt();?></span>
						</p>
					</div>

				<?php endwhile; endif;?>
				</div>
			<?php endif;?>

			<?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages); } ?>
	
		</div>
	</article>
</main><!-- // main  -->
<?php get_sidebar();?>

<?php get_footer();?>