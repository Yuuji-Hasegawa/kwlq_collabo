<?php

// ログイン画面のカスタマイズ
function custom_login_logo_url() {
  return home_url();
}
add_filter( 'login_headerurl', 'custom_login_logo_url' );

function custom_login_logo_title() {
  return get_option( 'blogname' );
}
add_filter( 'login_headertitle', 'custom_login_logo_title' );

// ダッシュボードのカスタマイズ
remove_action( 'welcome_panel', 'wp_welcome_panel' );
add_action( 'welcome_panel', 'add_links_welcome_panel' );
function add_links_welcome_panel() {
?>
  <style>
    /* welcome panel */
    .welcome-panel-close,
    #screen-options-wrap label[for="wp_welcome_panel-hide"] {
      display: none;
    }
    #welcome-panel {
      display: block;
    }
    .welcome-panel {
      padding: 0;
    }
    .welcome-panel .lead {
      margin: 0 0 1rem;
      padding: 0.5rem;
      color: #333;
      font-weight: bold;
      border-bottom: solid 1px #eaeaea;
    }
    .welcome-panel .lead:nth-of-type(2) {
      border-top: solid 1px #eaeaea;
    }
    .welcome-panel .btn-area {
      padding: 0 1rem;
      box-sizing: border-box;
    }
    .welcome-panel ul {
        margin: 0;
        padding: 0;
    }
    .welcome-panel ul li {
        list-style: none;
        display: inline-block;
        margin-bottom: 1rem;
    }
    .welcome-panel button{
      margin: 0;
      padding: 0;
      border: none;
    }
    .welcome-panel button a {
      color: #fff;
      background: #366393;
      padding: 1rem 2rem;
      display: block;
      font-size: 1rem;
      border-radius: 4px;
      position: relative;
    }
    .welcome-panel button a:hover {
      opacity: .65;
    }
    .welcome-panel button a img {
      position: relative;
      top: 5px;
      padding-right: 5px;
    }
  </style>
  <p class="lead">各種投稿</p>
  <div class="btn-area">
    <ul>
      <li><button><a href="edit.php?post_type=news"><span><img src="<?php echo get_template_directory_uri();?>/img/icon_news.png"></span>お知らせ 記事一覧</a></button></li>
      <li><button><a href="post-new.php?post_type=news"><span><img src="<?php echo get_template_directory_uri();?>/img/icon_news.png"></span>お知らせ 新規追加</a></button></li>
      <li><button><a href="edit.php?post_type=blog"><span><img src="<?php echo get_template_directory_uri();?>/img/icon_blogs.png"></span>ブログ 記事一覧</a></button></li>
      <li><button><a href="post-new.php?post_type=blog"><span><img src="<?php echo get_template_directory_uri();?>/img/icon_blogs.png"></span>ブログ 新規追加</a></button></li>
    </ul>
  </div>
  <p class="lead">固定ページ</p>
  <div class="btn-area">
    <ul>
      <li><button><a href="edit.php?post_type=page"><span class="dashicons dashicons-admin-page"></span>固定ページ 一覧</a></button></li>
      <li><button><a href="post-new.php?post_type=page"><span class="dashicons dashicons-admin-page"></span>固定ページ 新規追加</a></button></li>
    </ul>
  </div>
<?php
}
// カスタム投稿の設定
/* カスタム投稿 */
/* カスタム投稿タイプの追加 */
add_action( 'init', 'create_post_type' );
function create_post_type() {
  register_post_type( 'news', /* post-type */
    array(
      'labels' => array(
        'name' => 'お知らせ',
        'singular_name' => 'お知らせ',
  'add_new_item' => 'お知らせの新規追加',
      'edit_item' => 'お知らせの編集'
      ),
      'public' => true,
      'menu_position' =>10,
      'has_archive' => true,
      'yarpp_support' => true,
      'menu_icon' => get_template_directory_uri().'/img/icon_news.png',
      'supports' => array('title','editor')
    )
  );
  register_post_type( 'blog', /* post-type */
    array(
      'labels' => array(
        'name' => 'ブログ',
        'singular_name' => 'ブログ',
        'add_new_item' => 'ブログの新規追加',
        'edit_item' => 'ブログの編集'
      ),
      'public' => true,
      'menu_position' =>6,
      'menu_icon' => get_template_directory_uri().'/img/icon_blogs.png',
      'has_archive' => true,
      'yarpp_support' => true,
      'supports' => array('title','editor','author','excerpt','thumbnail')
    )
  );
}

/* post_id.htmlにRewrite */
add_action('init', 'myposttype_rewrite');
function myposttype_rewrite() {
    global $wp_rewrite;

    $queryarg = 'post_type=news&p=';
    $wp_rewrite->add_rewrite_tag('%news_id%', '([^/]+)',$queryarg);
    $wp_rewrite->add_permastruct('news', '/news/%news_id%.html', false);

    $queryarg = 'post_type=blog&p=';
    $wp_rewrite->add_rewrite_tag('%blog_id%', '([^/]+)',$queryarg);
    $wp_rewrite->add_permastruct('blog', '/blog/%blog_id%.html', false);

}

add_filter('post_type_link', 'myposttype_permalink', 1, 3);
 
function myposttype_permalink($post_link, $id = 0, $leavename) {
    global $wp_rewrite;
    $post = &get_post($id);
    if ( is_wp_error( $post ) )
        return $post;
    $newlink = $wp_rewrite->get_extra_permastruct($post->post_type);
    $newlink = str_replace('%'.$post->post_type.'_id%', $post->ID, $newlink);
    $newlink = home_url(user_trailingslashit($newlink));
    return $newlink;
}

// 初期設定の関数
add_theme_support('post-thumbnails');

function shortcode_sitename(){
    return bloginfo('name');
}
add_shortcode('site_name','shortcode_sitename');
wpcf7_add_shortcode('site_name','shortcode_sitename');

function shortcode_url() {
    return home_url();
}
add_shortcode('url', 'shortcode_url');
wpcf7_add_shortcode('url','shortcode_url');

function shortcode_templateurl() {
    return get_template_directory_uri();
}
add_shortcode('template_url', 'shortcode_templateurl');

//設定由来のショートコード
function shortcode_companyname() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_name'];
}
add_shortcode('company_name', 'shortcode_companyname');
wpcf7_add_shortcode('company_name','shortcode_companyname');

function shortcode_companyowner() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_owner'];
}
add_shortcode('company_owner', 'shortcode_companyowner');
wpcf7_add_shortcode('company_owner','shortcode_companyowner');

function shortcode_companyzip() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_zip'];
}
add_shortcode('company_zip', 'shortcode_companyzip');
wpcf7_add_shortcode('company_zip','shortcode_companyzip');

function shortcode_companyaddress() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_address'];
}
add_shortcode('company_address', 'shortcode_companyaddress');
wpcf7_add_shortcode('company_address','shortcode_companyaddress');

function shortcode_companytel() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_tel'];
}
add_shortcode('company_tel', 'shortcode_companytel');
wpcf7_add_shortcode('company_tel','shortcode_companytel');

function shortcode_companymail() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_mail'];
}
add_shortcode('company_mail', 'shortcode_companymail');
wpcf7_add_shortcode('company_mail','shortcode_companymail');

function shortcode_companybirth() {
    $my_options = get_option( 'extend_name' );
    return $my_options['company_birthday'];
}
add_shortcode('company_birthday', 'shortcode_companybirth');

function shortcode_policydate() {
    $my_options = get_option( 'extend_name' );
    return $my_options['policy_date'];
}
add_shortcode('policy_date', 'shortcode_policydate');

function shortcode_privacypost() {
    $my_options = get_option( 'extend_name' );
    return $my_options['privacy_post'];
}
add_shortcode('privacy_post', 'shortcode_privacypost');

function shortcode_courtname() {
    $my_options = get_option( 'extend_name' );
    return $my_options['court_name'];
}
add_shortcode('court_name', 'shortcode_courtname');

function shortcode_sitedomain() {
    $my_options = get_option( 'extend_name' );
    return $my_options['site_domain'];
}
add_shortcode('site_domain', 'shortcode_sitedomain');

//last-modified
function get_last_modified_date(){
  $date = array(
    get_the_modified_time("Y"),
    get_the_modified_time("m"),
    get_the_modified_time("d")
  );
  $time = array(
    get_the_modified_time("H"),
    get_the_modified_time("i"),
    get_the_modified_time("s"),
  );

  $time_str = implode("-", $date) . "T" . implode(":", $time) . "+09:00";

  // UNIXタイムスタンプに変換後、日付（RFC2822）を返す
  return date( "r", strtotime($time_str) );
}

function add_last_modified(){
  if( is_single() ){
    header( sprintf( "Last-Modified: %s", get_last_modified_date() ) );
  }
}

add_action( "template_redirect", "add_last_modified" );

add_action( "wp_head", "add_last_modified_meta" );
function add_last_modified_meta(){
  echo '<meta http-equiv="Last-Modified" content="'.
  get_last_modified_date().
  '">';
}

// 管理バーの項目を非表示
if (!current_user_can( 'administrator')) {
function remove_admin_bar_menu( $wp_admin_bar ) {
 $wp_admin_bar->remove_menu( 'wp-logo' ); // WordPressシンボルマーク
 $wp_admin_bar->remove_menu('my-account'); // マイアカウント
 }
add_action( 'admin_bar_menu', 'remove_admin_bar_menu', 70 );
}

// 管理バーのヘルプメニューを非表示にする
function my_admin_head(){
 echo '<style type="text/css">#contextual-help-link-wrap{display:none;}</style>';
 }
add_action('admin_head', 'my_admin_head');

// 管理バーにログアウトを追加
function add_new_item_in_admin_bar() {
 global $wp_admin_bar;
 $wp_admin_bar->add_menu(array(
 'id' => 'new_item_in_admin_bar',
 'title' => __('ログアウト'),
 'href' => wp_logout_url()
 ));
 }
add_action('wp_before_admin_bar_render', 'add_new_item_in_admin_bar');

// ダッシュボードウィジェット非表示
function example_remove_dashboard_widgets() {
 if (!current_user_can('level_7')) { //level10以下のユーザーの場合ウィジェットをunsetする
 global $wp_meta_boxes;
 unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']); // 現在の状況
 unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']); // 最近のコメント
 unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']); // 被リンク
 unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']); // プラグイン
 unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']); // クイック投稿
 unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']); // 最近の下書き
 unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']); // WordPressブログ
 unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']); // WordPressフォーラム
 }
 }
add_action('wp_dashboard_setup', 'example_remove_dashboard_widgets');

// 投稿画面の項目を非表示にする
function remove_default_post_screen_metaboxes() {
 if (!current_user_can('level_7')) { // level10以下のユーザーの場合メニューをremoveする
 remove_meta_box( 'postcustom','post','normal' ); // カスタムフィールド
 remove_meta_box( 'postexcerpt','post','normal' ); // 抜粋
 remove_meta_box( 'commentstatusdiv','post','normal' ); // ディスカッション
 remove_meta_box( 'commentsdiv','post','normal' ); // コメント
 remove_meta_box( 'trackbacksdiv','post','normal' ); // トラックバック
 remove_meta_box( 'authordiv','post','normal' ); // 作成者
 remove_meta_box( 'slugdiv','post','normal' ); // スラッグ
 remove_meta_box( 'revisionsdiv','post','normal' ); // リビジョン
 }
 }
add_action('admin_menu','remove_default_post_screen_metaboxes');

/*
 * メディアの抽出条件にログインユーザーの絞り込み条件を追加する
 */
function display_only_self_uploaded_medias( $wp_query ) {
    if ( is_admin() && ( $wp_query->is_main_query() || ( defined( 'DOING_QUERY_ATTACHMENT' ) && DOING_QUERY_ATTACHMENT ) ) && $wp_query->get( 'post_type' ) == 'attachment' ) {
        $user = wp_get_current_user();
        $wp_query->set( 'author', $user->ID );
    }
}
function define_doing_query_attachment_const() {
    if ( ! defined( 'DOING_QUERY_ATTACHMENT' ) ) {
        define( 'DOING_QUERY_ATTACHMENT', true );
    }
}

get_currentuserinfo();
if($current_user->user_level < 7){
    add_action( 'pre_get_posts', 'display_only_self_uploaded_medias' );
    add_action( 'wp_ajax_query-attachments', 'define_doing_query_attachment_const', 0 );
}

//入力画面 現在の状況　のWordPress表示を消す
function my_admin_print_styles(){
    if (!current_user_can('level_7')) {
        echo '<style type="text/css">.versions p,#wp-version-message{display:none;}</style>';
    }
}
add_action('admin_print_styles', 'my_admin_print_styles', 21);

function remove_menus () {
 if (!current_user_can('level_7')) { //level10以下のユーザーの場合メニューをunsetする
 remove_menu_page('wpcf7'); //Contact Form 7
 global $menu;
 unset($menu[2]); // ダッシュボード
 //unset($menu[4]); // メニューの線1
 unset($menu[5]); // 投稿
 //unset($menu[10]); // メディア
 unset($menu[15]); // リンク
 unset($menu[20]); // ページ
 unset($menu[25]); // コメント
 //unset($menu[59]); // メニューの線2
 unset($menu[60]); // テーマ
 unset($menu[65]); // プラグイン
 //unset($menu[70]); // プロフィール
 unset($menu[75]); // ツール
 unset($menu[80]); // 設定
 unset($menu[90]); // メニューの線3
 }
 }
add_action('admin_menu', 'remove_menus');

// 不要なタグ削除
// バージョン更新を非表示にする
if (!current_user_can( 'administrator')) {
add_filter('pre_site_transient_update_core', '__return_zero');
}
// APIによるバージョンチェックの通信をさせない
if (!current_user_can( 'administrator')) {
remove_action('wp_version_check', 'wp_version_check');
remove_action('admin_init', '_maybe_update_core');
}

// 不要なヘッダタグ削除
remove_action( 'wp_head', 'feed_links', 2 ); //サイト全体のフィード
remove_action( 'wp_head', 'feed_links_extra', 3 ); //その他のフィード
remove_action( 'wp_head', 'rsd_link' ); //Really Simple Discoveryリンク
remove_action( 'wp_head', 'wlwmanifest_link' ); //Windows Live Writerリンク
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 ); //前後の記事リンク
remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 ); //ショートリンク
remove_action( 'wp_head', 'rel_canonical' ); //canonical属性
remove_action( 'wp_head', 'wp_generator' ); //WPバージョン

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('wp_print_styles', 'print_emoji_styles' );
remove_action('admin_print_styles', 'print_emoji_styles');

// self_pinback
function no_self_ping( &$links ) {
    $home = get_option( 'home' );
    foreach ( $links as $l => $link )
        if ( 0 === strpos( $link, $home ) )
            unset($links[$l]);
}
add_action( 'pre_ping', 'no_self_ping' );

// 便利機能の設定
function pagination($pages = '', $range = 1)
{
     $showitems = ($range * 2)+1;  
 
     global $paged;
     if(empty($paged)) $paged = 1;
 
     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   
 
     if(1 != $pages)
     {
         echo "<div class=\"pagination tcenter\"><div class=\"pagination-box\">";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a class=\"block\" href='".get_pagenum_link(1)."'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a class=\"block\" href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";
 
         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class=\"current block\">".$i."</span>":"<a class=\"block\" href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
             }
         }
 
         if ($paged < $pages && $showitems < $pages) echo "<a class=\"block\" href=\"".get_pagenum_link($paged + 1)."\">&rsaquo;</a>";
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a class=\"block\" href='".get_pagenum_link($pages)."'>&raquo;</a>";
         echo "</div></div>\n";
     }
}

// meta robotsの制御
function robots() {
  // 検索結果、404、カテゴリー以外のアーカイブ(タグ・投稿者・日時)、トップページ２ページ目以降はnoindex,followに
  if (is_search() || is_404() || (is_archive() && !is_category()) || (is_home() && is_paged())) {
    $content = 'noindex,follow';
  // トップページの１ページ目 or 投稿・固定ページはindex,followに
  } elseif ((is_home() && !is_paged()) || is_singular()) {
    $content = 'index,follow';
  }
  echo $content;
}

//自動整形 制御
add_filter('the_content', 'wpautop_filter', 9);
function wpautop_filter($content) {
global $post;
$remove_filter = false;
 
$arr_types = array('page','blog'); /*自動整形を解除・無効にする投稿タイプを記述*/
$post_type = get_post_type( $post->ID );
if (in_array($post_type, $arr_types)) $remove_filter = true;
 
if ( $remove_filter ) {
remove_filter('the_content', 'wpautop');
remove_filter('the_excerpt', 'wpautop');
}
return $content;
}

// 設定画面の設定
//画像アップロード用のタグを出力する
function generate_upload_image_tag($name, $value){?>
  <input name="<?php echo $name; ?>" type="text" value="<?php echo $value; ?>" />
  <input type="button" name="<?php echo $name; ?>_slect" value="選択" />
  <input type="button" name="<?php echo $name; ?>_clear" value="クリア" />
  <div id="<?php echo $name; ?>_thumbnail" class="uploded-thumbnail">
    <?php if ($value): ?>
      <img src="<?php echo $value; ?>" alt="選択中の画像">
    <?php endif ?>
  </div>


  <script type="text/javascript">
  (function ($) {

      var custom_uploader;

      $('input:button[name="<?php echo $name; ?>_slect"]').click(function(e) {

          e.preventDefault();

          if (custom_uploader) {

              custom_uploader.open();
              return;

          }

          custom_uploader = wp.media({

              title: "画像を選択してください",

              /* ライブラリの一覧は画像のみにする */
              library: {
                  type: "image"
              },

              button: {
                  text: "画像の選択"
              },

              /* 選択できる画像は 1 つだけにする */
              multiple: false

          });

          custom_uploader.on("select", function() {

              var images = custom_uploader.state().get("selection");

              /* file の中に選択された画像の各種情報が入っている */
              images.each(function(file){

                  /* テキストフォームと表示されたサムネイル画像があればクリア */
                  $('input:text[name="<?php echo $name; ?>"]').val("");
                  $("#<?php echo $name; ?>_thumbnail").empty();

                  /* テキストフォームに画像の URL を表示 */
                  $('input:text[name="<?php echo $name; ?>"]').val(file.attributes.sizes.full.url);

                  /* プレビュー用に選択されたサムネイル画像を表示 */
                  $("#<?php echo $name; ?>_thumbnail").append('<img src="'+file.attributes.sizes.full.url+'" />');

              });
          });

          custom_uploader.open();

      });

      /* クリアボタンを押した時の処理 */
      $('input:button[name="<?php echo $name; ?>_clear"]').click(function() {

          $('input:text[name="<?php echo $name; ?>"]').val("");
          $("#<?php echo $name; ?>_thumbnail").empty();

      });

  })(jQuery);
  </script>
  <?php
}

function my_admin_scripts() {
  //メディアアップローダの javascript API
  wp_enqueue_media();
}
add_action( 'admin_print_scripts', 'my_admin_scripts' );

class ExtendPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'BBN拡張ページ', 
            'BBN拡張ページ', 
            'manage_options', 
            'bbn-extends', 
            array( $this, 'create_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'extend_name' );
        ?>
        <div class="wrap">
            <?php screen_icon(); ?>
            <h2>BBNテーマの拡張設定</h2>           
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'extends_group' );   
                do_settings_sections( 'bbn-extends' );
                submit_button(); 
            ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'extends_group', // Option group
            'extend_name', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'company_data', // ID
            '企業情報', // Title
            array( $this, 'print_section_info' ), // Callback
            'bbn-extends' // Page
        );

        add_settings_section(
            'site_data', // ID
            'サイトデータ', // Title
            array( $this, 'print_section_info' ), // Callback
            'bbn-extends' // Page
        );

        add_settings_section(
            'ogp_data', // ID
            'OGP情報', // Title
            array( $this, 'print_section_info' ), // Callback
            'bbn-extends' // Page
        );  

        add_settings_field(
            'company_name', 
            '会社名・屋号', 
            array( $this, 'company_name_callback' ), 
            'bbn-extends', 
            'company_data'
        );

        add_settings_field(
            'company_owner', 
            '代表者名', 
            array( $this, 'company_owner_callback' ), 
            'bbn-extends', 
            'company_data'
        );

        add_settings_field(
            'company_zip', 
            '郵便番号', 
            array( $this, 'company_zip_callback' ), 
            'bbn-extends', 
            'company_data'
        );

        add_settings_field(
            'company_address', 
            '所在地', 
            array( $this, 'company_address_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'company_tel', 
            '電話番号', 
            array( $this, 'company_tel_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'company_mail', 
            'メールアドレス', 
            array( $this, 'company_mail_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'company_birthday', 
            '創立日', 
            array( $this, 'company_birthday_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'policy_date', 
            '規約制定日', 
            array( $this, 'policy_date_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'privacy_post', 
            '個人情報管理担当者', 
            array( $this, 'privacy_post_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'court_name', 
            '管轄裁判所', 
            array( $this, 'court_name_callback' ), 
            'bbn-extends', 
            'company_data'
        );
        add_settings_field(
            'site_domain', 
            'ドメイン名', 
            array( $this, 'site_domain_callback' ), 
            'bbn-extends', 
            'site_data'
        );
        add_settings_field(
            'keywords', 
            'メタキーワード', 
            array( $this, 'keywords_callback' ), 
            'bbn-extends', 
            'site_data'
        );
        add_settings_field(
            'favicon', 
            'favicon', 
            array( $this, 'favicon_callback' ), 
            'bbn-extends', 
            'site_data'
        );
        add_settings_field(
            'webclip', 
            'Webクリップアイコン', 
            array( $this, 'webclip_callback' ), 
            'bbn-extends', 
            'site_data'
        );
        add_settings_field(
            'copyright', 
            '著作権表記', 
            array( $this, 'copyright_callback' ), 
            'bbn-extends', 
            'site_data'
        );
        add_settings_field(
            'ogp_img', 
            'デフォルトOGP画像', 
            array( $this, 'ogp_img_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );
        add_settings_field(
            'fb_appid', 
            'FBアプリID', 
            array( $this, 'fb_appid_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );
        add_settings_field(
            'fb_publisher', 
            'FBページ', 
            array( $this, 'fb_publisher_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );
        add_settings_field(
            'tw_site', 
            'サイト管理者のTWアカウント', 
            array( $this, 'tw_site_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );
        add_settings_field(
            'tw_creator', 
            '執筆者のTWアカウント', 
            array( $this, 'tw_creator_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );
        add_settings_field(
            'gu_author', 
            'g+執筆者アカウント', 
            array( $this, 'gu_author_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );
        add_settings_field(
            'gu_publisher', 
            'g+サイトアカウント', 
            array( $this, 'gu_publisher_callback' ), 
            'bbn-extends', 
            'ogp_data'
        );      
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['company_name'] ) )
            $new_input['company_name'] = sanitize_text_field( $input['company_name'] );

        if( isset( $input['company_owner'] ) )
            $new_input['company_owner'] = sanitize_text_field( $input['company_owner'] );

        if( isset( $input['company_zip'] ) )
            $new_input['company_zip'] = sanitize_text_field( $input['company_zip'] );

        if( isset( $input['company_address'] ) )
            $new_input['company_address'] = sanitize_text_field( $input['company_address'] );

        if( isset( $input['company_tel'] ) )
            $new_input['company_tel'] = sanitize_text_field( $input['company_tel'] );

        if( isset( $input['company_mail'] ) )
            $new_input['company_mail'] = sanitize_email( $input['company_mail'] );

        if( isset( $input['company_birthday'] ) )
            $new_input['company_birthday'] = sanitize_text_field( $input['company_birthday'] );

        if( isset( $input['policy_date'] ) )
            $new_input['policy_date'] = sanitize_text_field( $input['policy_date'] );

        if( isset( $input['privacy_post'] ) )
            $new_input['privacy_post'] = sanitize_text_field( $input['privacy_post'] );

        if( isset( $input['court_name'] ) )
            $new_input['court_name'] = sanitize_text_field( $input['court_name'] );

        if( isset( $input['site_domain'] ) )
            $new_input['site_domain'] = sanitize_text_field( $input['site_domain'] );

        if( isset( $input['keywords'] ) )
            $new_input['keywords'] = sanitize_text_field( $input['keywords'] );

        if( isset( $input['favicon'] ) )
            $new_input['favicon'] = sanitize_text_field( $input['favicon'] );

        if( isset( $input['webclip'] ) )
            $new_input['webclip'] = sanitize_text_field( $input['webclip'] );

        if( isset( $input['copyright'] ) )
            $new_input['copyright'] = sanitize_text_field( $input['copyright'] );

        if( isset( $input['ogp_img'] ) )
            $new_input['ogp_img'] = sanitize_text_field( $input['ogp_img'] );

        if( isset( $input['fb_appid'] ) )
            $new_input['fb_appid'] = sanitize_text_field( $input['fb_appid'] );

        if( isset( $input['fb_publisher'] ) )
            $new_input['fb_publisher'] = esc_url_raw( $input['fb_publisher'] );

        if( isset( $input['tw_site'] ) )
            $new_input['tw_site'] = sanitize_text_field( $input['tw_site'] );

        if( isset( $input['tw_creator'] ) )
            $new_input['tw_creator'] = sanitize_text_field( $input['tw_creator'] );

        if( isset( $input['gu_author'] ) )
            $new_input['gu_author'] = esc_url_raw( $input['gu_author'] );

        if( isset( $input['gu_publisher'] ) )
            $new_input['gu_publisher'] = esc_url_raw( $input['gu_publisher'] );

        return $new_input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        return;
    }

    /** 
     * Get the settings option array and print one of its values
     */

    public function company_name_callback()
    {
        printf(
            '<input type="text" id="company_name" name="extend_name[company_name]" value="%s" />',
            isset( $this->options['company_name'] ) ? esc_attr( $this->options['company_name']) : ''
        );
    }

    public function company_owner_callback()
    {
        printf(
            '<input type="text" id="company_owner" name="extend_name[company_owner]" value="%s" />',
            isset( $this->options['company_owner'] ) ? esc_attr( $this->options['company_owner']) : ''
        );
    }

    public function company_zip_callback()
    {
        printf(
            '<input type="text" id="company_zip" name="extend_name[company_zip]" value="%s" />',
            isset( $this->options['company_zip'] ) ? esc_attr( $this->options['company_zip']) : ''
        );
    }

    public function company_address_callback()
    {
        printf(
            '<input type="text" id="company_address" name="extend_name[company_address]" value="%s" />',
            isset( $this->options['company_address'] ) ? esc_attr( $this->options['company_address']) : ''
        );
    }

    public function company_tel_callback()
    {
        printf(
            '<input type="tel" id="company_tel" name="extend_name[company_tel]" value="%s" />',
            isset( $this->options['company_tel'] ) ? esc_attr( $this->options['company_tel']) : ''
        );
    }

    public function company_mail_callback()
    {
        printf(
            '<input type="mail" id="company_mail" name="extend_name[company_mail]" value="%s" />',
            isset( $this->options['company_mail'] ) ? esc_attr( $this->options['company_mail']) : ''
        );
    }

    public function company_birthday_callback()
    {
        printf(
            '<input type="text" id="company_birthday" name="extend_name[company_birthday]" value="%s" />',
            isset( $this->options['company_birthday'] ) ? esc_attr( $this->options['company_birthday']) : ''
        );
    }

    public function policy_date_callback()
    {
        printf(
            '<input type="text" id="policy_date" name="extend_name[policy_date]" value="%s" />',
            isset( $this->options['policy_date'] ) ? esc_attr( $this->options['policy_date']) : ''
        );
    }

    public function privacy_post_callback()
    {
        printf(
            '<input type="text" id="privacy_post" name="extend_name[privacy_post]" value="%s" />',
            isset( $this->options['privacy_post'] ) ? esc_attr( $this->options['privacy_post']) : ''
        );
    }

    public function court_name_callback()
    {
        printf(
            '<input type="text" id="court_name" name="extend_name[court_name]" value="%s" />',
            isset( $this->options['court_name'] ) ? esc_attr( $this->options['court_name']) : ''
        );
    }

    public function site_domain_callback()
    {
        printf(
            '<input type="text" id="site_domain" name="extend_name[site_domain]" value="%s" />',
            isset( $this->options['site_domain'] ) ? esc_attr( $this->options['site_domain']) : ''
        );
    }

    public function keywords_callback()
    {
        printf(
            '<input type="text" id="keywords" name="extend_name[keywords]" value="%s" />',
            isset( $this->options['keywords'] ) ? esc_attr( $this->options['keywords']) : ''
        );
    }
    public function favicon_callback(){
        generate_upload_image_tag('extend_name[favicon]', $this->options['favicon']);
    }
    public function webclip_callback(){
        generate_upload_image_tag('extend_name[webclip]', $this->options['webclip']);
    }

    public function copyright_callback()
    {
        printf(
            '<input type="text" id="copyright" name="extend_name[copyright]" value="%s" />',
            isset( $this->options['copyright'] ) ? esc_attr( $this->options['copyright']) : ''
        );
    }

    public function ogp_img_callback(){
        generate_upload_image_tag('extend_name[ogp_img]', $this->options['ogp_img']);
    }

    public function fb_appid_callback()
    {
        printf(
            '<input type="text" id="fb_appid" name="extend_name[fb_appid]" value="%s" />',
            isset( $this->options['fb_appid'] ) ? esc_attr( $this->options['fb_appid']) : ''
        );
    }

    public function fb_publisher_callback()
    {
        printf(
            '<input type="text" id="fb_publisher" name="extend_name[fb_publisher]" value="%s" />',
            isset( $this->options['fb_publisher'] ) ? esc_url_raw( $this->options['fb_publisher']) : ''
        );
    }

    public function tw_site_callback()
    {
        printf(
            '<input type="text" id="tw_site" name="extend_name[tw_site]" value="%s" />',
            isset( $this->options['tw_site'] ) ? esc_attr( $this->options['tw_site']) : ''
        );
    }

    public function tw_creator_callback()
    {
        printf(
            '<input type="text" id="tw_creator" name="extend_name[tw_creator]" value="%s" />',
            isset( $this->options['tw_creator'] ) ? esc_attr( $this->options['tw_creator']) : ''
        );
    }

    public function gu_author_callback()
    {
        printf(
            '<input type="text" id="gu_author" name="extend_name[gu_author]" value="%s" />',
            isset( $this->options['gu_author'] ) ? esc_url_raw( $this->options['gu_author']) : ''
        );
    }

    public function gu_publisher_callback()
    {
        printf(
            '<input type="text" id="gu_publisher" name="extend_name[gu_publisher]" value="%s" />',
            isset( $this->options['gu_publisher'] ) ? esc_url_raw( $this->options['gu_publisher']) : ''
        );
    }
}

if( is_admin() )
    $extend_page = new ExtendPage();

// AMPの設定
// AMPページの条件分岐
function is_amp() {
$is_amp = false;
if (function_exists('is_amp_endpoint') && is_amp_endpoint()) {
$is_amp = true;
}
return $is_amp;
}

add_action( 'pre_amp_render_post', 'xyz_amp_add_custom_actions' );
function xyz_amp_add_custom_actions() {
add_filter( 'the_content', 'my_amp_custom_main_content' );
}
function my_amp_custom_main_content ( $content ) {
// ここに下で紹介する置換に関するコードを追加していく
// いろいろ削除
$content = preg_replace(array(
'/<script[^<]*?<\/script>/iu', // scriptを削除
'/style="[^"]*?"/iu', // styleを削除
'/border="[^"]*?"/iu', // borderを削除
'/target="[^"]*?"/iu', // targetを削除
'/onclick="[^"]*?"/iu', // onclickを削除
'/scale="[^"]*?"/iu' // scaleを削除
), '', $content);
// Twitterをamp-twitterに置換する（埋め込みコード）
$pattern = '/<blockquote class="twitter-(tweet|video)".*?>.+?<a href="https:\/\/twitter.com\/.*?\/status\/(.*?)">.+?<\/blockquote>/iu';
$replacement = '<amp-twitter width=592 height=472 layout="responsive" data-tweetid="$2"></amp-twitter>';
$content = preg_replace($pattern, $replacement, $content);
// YouTubeをamp-youtubeに置換する(埋め込みコード)
$pattern = '/<iframe[^>]+?youtube\.com\/embed\/(.+?)(\?[^>]+?)?"[^<]+?<\/iframe>/iu';
$replacement = '<amp-youtube layout="responsive" data-videoid="$1" width="560" height="315"></amp-youtube>';
$content = preg_replace($pattern, $replacement, $content);
// ついでにiframeも置換する
$pattern = '/<iframe ([^<]+?)<\/iframe>/iu';
$replacement = '<amp-iframe layout="responsive" $1</amp-iframe>';
$content = preg_replace($pattern, $replacement, $content);
// 画像にサイズ(widthとheight)を追加
$pattern = '/<img [^>]*?src="(https?:\/\/[^"]+?)"[^>]*?>/iu';
preg_match_all($pattern, $content, $imgs);
foreach ( $imgs[0] as $i => $img ) {
if ( false !== strpos( $img, 'width=' ) && false !== strpos( $img, 'height=' ) ) {
continue;
}
$img_url = $imgs[1][$i]; // 画像url
$img_size = @getimagesize( $img_url ); // 画像サイズを取得
if ( false === $img_size ) {
continue;
}
$replaced_img = str_replace( '<img ', '<img ' . $img_size[3] . ' ', $imgs[0][$i] );
$content = str_replace( $img, $replaced_img, $content );
}
// imgタグをamp-imgタグに置換
$pattern = '/<img ([^>]+?)\/?>/i';
$replacement = '<amp-img layout="responsive" $1></amp-img>';
$content = preg_replace($pattern, $replacement, $content);

return $content;
}

/* 以下、個別でカスタマイズしたいものを中心に */

/* widget */
if (function_exists('register_sidebar')) {
 register_sidebar(array(
 'name' => 'widget-sidebar',
 'id' => 'widget-sidebar',
 'before_widget' => '<div class="aside-content">',
 'after_widget' => '</div>',
 'before_title' => '<h3>',
 'after_title' => '</h3>'
 ));
}

add_filter('widget_text', 'do_shortcode' );

// フッターWordPressリンクを非表示に。メールアドレスは書き換えること
function custom_admin_footer() {
 echo '<a href="mailto:info@kamenwriter.com">管理者へのお問い合わせ</a>';
 }
add_filter('admin_footer_text', 'custom_admin_footer');

/* Breadcrumb NavXT用の設定 */
function my_bcn_allowed_html($allowed_html)
{
    $allowed_html['li'] = array(
        'title' => true,
        'class' => true,
        'id' => true,
        'itemprop' => true,
        'itemscope' => true,
        'itemtype' => true
    );
    return $allowed_html;
}
add_filter('bcn_allowed_html', 'my_bcn_allowed_html');

/* CF7のjs、CSSの読み込み制御 */
add_filter( 'wpcf7_load_js', '__return_false' );
add_filter( 'wpcf7_load_css', '__return_false' );

add_filter('wpcf_type', 'yarpp_support_func', 10, 2);
function yarpp_support_func($data, $post_type){
  if(in_array($post_type, array('blog')))
  {
    $data['yarpp_support'] = true;
  }
  return $data;
}

?>