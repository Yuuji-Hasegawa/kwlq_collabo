<?php get_header();?>
	<section class="nfbody">
		<div class="container">
			<p class="lead">お探しのページは見つかりませんでした。</p>
			<p>大変申し訳ありません。お探しのページは</p>
			<ul>
				<li class="mb1rem">すでに削除されている・公開期間が終わっている</li>
				<li class="mb1rem">アクセスしたアドレスが異なっている</li>
			</ul>
			<p>などの理由で見つかりませんでした。</p>
			<p>引き続き、このサイトをご利用いただく場合は、</p>
			<ul>
				<li class="mb1rem"><a href="<?php echo home_url();?>">トップページ</a>から改めてリンクをたどる</li>
				<li class="mb1rem"><a href="<?php echo home_url();?>/sitemaps">サイトマップ</a>を参照する</li>
			</ul>
			<p>上記の方法をご利用ください。</p>
			<button class="default mt2rem box-center"><a href="<?php echo home_url();?>"><b>トップページへ戻る</b></a></button>
		</div>
	</section>
</main><!-- // main  -->
<?php get_sidebar();?>

<?php get_footer();?>