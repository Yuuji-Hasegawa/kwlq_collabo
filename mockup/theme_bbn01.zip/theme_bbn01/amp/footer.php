<?php $my_options = get_option( 'extend_name' );?>
</section>
<footer>
	<div class="container">
		<section class="ft-address box-center">
			<p class="ft-logo tcenter"><a href="<?php echo home_url();?>"><amp-img src="<?php echo get_template_directory_uri();?>/img/logo_s.png" width="280" height="60" alt="logo" layout="responsive"></a></p>
			<p><?php echo $my_options['company_name'];?> TEL:<a href="tel:<?php echo $my_options['company_tel'];?>"> <?php echo $my_options['company_tel'];?></a></p>
			<p>〒<?php echo $my_options['company_zip'];?><br><?php echo $my_options['company_address'];?></p>
		</section>
		<nav class="ft-nav">
			<ul class="flex-list box-center">
				<li class="tcenter"><a href="<?php echo home_url();?>/company">会社概要</a></li>
				<li class="tcenter"><a href="<?php echo home_url();?>/site-policy">利用規約</a></li>
				<li class="tcenter"><a href="<?php echo home_url();?>/privacy-policy">個人情報保護方針</a></li>
				<li class="tcenter"><a href="<?php echo home_url();?>/sitemaps">サイトマップ</a></li>					
			</ul>
		</nav>
	</div>
	<section class="ft-bottom flex-between">
		<nav>
			<ul class="flex-list">
				<li><a href="https://twitter.com/"><i class="fab fa-fw fa-twitter"></i></a></li>
				<li><a href="https://www.facebook.com/"><i class="fab fa-fw fa-facebook-f"></i></a></li>
				<li><a href="https://www.instagram.com/"><i class="fab fa-fw fa-instagram"></i></a></li>
			</ul>
		</nav>
		<p class="cpt">© <?php echo $my_options['copyright'];?></p>
	</section>
</footer>
</body>
</html>