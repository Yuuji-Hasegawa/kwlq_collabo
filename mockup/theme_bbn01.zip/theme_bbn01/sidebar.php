<aside>

<?php if(is_front_page()):?>
		
	<section class="news ph2rem">
		<div class="container">
			<div class="onecolumn box-center">
				<h2>News</h2>
				<?php
					$args = array(
						'post_type' => 'news', /* 投稿タイプを指定 */
						'posts_per_page' => 3, // 表示件数
						'order' => 'date',
						'order' => 'DESC',
					);
					$the_query = new WP_Query( $args );?>
				<?php if ( $the_query->have_posts() ) : ?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

						<dl class="news-dl">
							<dt><?php the_time('Y.m.d');?></dt>
							<dd><a href="<?php the_permalink();?>"><?php the_title();?></a></dd>
						</dl>

					<?php endwhile;?>
					<?php wp_reset_postdata(); ?>
				<?php else : ?>
					<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
				<?php endif; ?>
				<button class="default box-center mt2rem mb2rem"><a href="<?php echo home_url();?>/news">MORE</a></button>
			</div>
		</div>
	</section>

	<section class="blogs ph2rem">
		<div class="container">
			<h2>Blogs</h2>
			<?php
				$args = array(
					'post_type' => 'blog', /* 投稿タイプを指定 */
					'posts_per_page' => 4, // 表示件数
					'order' => 'date',
					'order' => 'DESC',
				);
				$the_query = new WP_Query( $args );?>
			<div class="flex-list blog-list">
				<?php if ( $the_query->have_posts() ) : ?>
					
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

						<div class="flex-half mb2rem">
							<p class="blog-thumb">
								<a href="<?php the_permalink();?>">
									<?php if(!has_post_thumbnail()) :?>
											<img src="<?php echo get_template_directory_uri();?>/img/thumb_dummy.png"/>
									<?php else:?>
										<?php the_post_thumbnail('full-size');?>
									<?php endif;?>
								</a>
							</p>
							<p class="blog-text">
								<span><?php the_time('Y.m.d');?></span>
								<span><a href="<?php the_permalink();?>"><?php the_title();?></a></span>
								<span><?php the_excerpt();?></span>
							</p>
						</div>

					<?php endwhile;?>
					<?php wp_reset_postdata(); ?>
				<?php else : ?>
					<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
				<?php endif; ?>
			</div>
			<button class="default box-center mt2rem mb2rem"><a href="<?php echo home_url();?>/blog">MORE</a></button>
		</div>
	</section>

<?php else :?>

	<div class="container">
		<!-- widget area -->
			<?php if ( ! is_active_sidebar( 'widget-sidebar' ) ) {return;}?>
			<?php dynamic_sidebar( 'widget-sidebar' ); ?>
		<!-- //widget area -->
	</div>

<?php endif;?>

</aside>